<a href="https://github.com/ILikeMintChocolate/Crwft">
  <img src="https://user-images.githubusercontent.com/99123542/171640603-4f29f525-0137-48d4-a948-dab27b468f46.png" width="200" height="100">
</a>
                                                                                                                                     
# crwft / WebRTC Server

크래프트의 WebRTC Server 입니다.
브라우저간 통신 시 시그널링 서버로 사용됩니다.

## 실행방법
설치
```
git clone https://github.com/ILikeMintChocolate/Crwft.git
cd WebRTC Server
npm install 
npm install nodemon -D
npm install @babel/core @babel/cli @babel/node -D
npm install @babel/preset-env -D
npm install express
npm install pug
npm install ws
npm install socket.io
```
실행
```
npm run dev
```
